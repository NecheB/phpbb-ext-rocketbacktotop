<?php
$lang_set_ext[] = [
    'ext_name' => 'nechev/rocketbacktotop',
    'lang_set' => 'common',
];

