<?php
namespace nechev\rocketbacktotop;

class ext extends \phpbb\extension\base
{
}
